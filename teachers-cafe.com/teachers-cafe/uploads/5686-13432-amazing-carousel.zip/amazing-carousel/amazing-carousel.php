<?php
/*
Plugin Name: Amazing Carousel
Plugin URI: http://demo.wpeffects.com/
Description: Amazing Carousel is a responsive CSS3 3D style carousel wordpress plugin.
Author: Noor-E-Alam
Author URI: http://demo.wpeffects.com/
Version: 1.5
*/



//Loading CSS & jquery
function ddd_carousel_scripts() {
	
	wp_enqueue_script('jquery');
	wp_enqueue_style('font-awesoggme', plugins_url( '/assets/css/font-awesome.css' , __FILE__ ) );
	wp_enqueue_style('bootstrap', plugins_url( '/assets/css/bootstrap.min.css' , __FILE__ ) );
	wp_enqueue_style('main-css', plugins_url( '/assets/css/cardslider.css' , __FILE__ ) );
	wp_enqueue_script('main-js', plugins_url( '/assets/js/jquery.cardslider.min.js' , __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'ddd_carousel_scripts' );



//Loading framework

if(!class_exists('3D-Carousel')){
// Setup Contants 
defined( 'VP_CAROUSEL_VERSION' ) or define( 'VP_CAROUSEL_VERSION', '2.0' );
defined( 'VP_CAROUSEL_URL' )     or define( 'VP_CAROUSEL_URL', plugin_dir_url( __FILE__ ) );
defined( 'VP_CAROUSEL_DIR' )     or define( 'VP_CAROUSEL_DIR', plugin_dir_path( __FILE__ ) );
defined( 'VP_CAROUSEL_FILE' )    or define( 'VP_CAROUSEL_FILE', __FILE__ );


// Loading framework bootstrap
require 'framework/bootstrap.php';
require 'data-control.php';

}



require 'custom-post.php';
require 'shortcode.php';

// Load Metaboxes 
new VP_Metabox(array
(
			'id'          => 'carousel_metabox',
			'types'       => array('amazing-carousel'),
			'title'       => __('Carousel Data ', 'vp_textdomain'),
			'priority'    => 'high',
			'template' => VP_CAROUSEL_DIR . '/admin/metabox.php'
));


// Load Settings Metaboxes 
new VP_Metabox(array
(
			'id'          => 'carousel_settings_metabox',
			'types'       => array('amazing-carousel'),
			'title'       => __('Carousel Settings ', 'vp_textdomain'),
			'priority'    => 'high',
			'template' => VP_CAROUSEL_DIR . '/admin/settings.php'
));

// Shortcode Metabox
new VP_Metabox(array
(
			'id'          => 'sidemeta',
			'types'       => array('amazing-carousel'),
			'title'       => __('Your Shortcode', 'vp_textdomain'),
			'priority'    => 'high',
			'context'     => 'side',
			'template' => VP_CAROUSEL_DIR . '/admin/sidemeta.php'
));

// embed font function
function carousel_embed_fonts()
{
    // you can directly enqueue and register
    VP_Site_GoogleWebFont::instance()->register_and_enqueue();
    // or register and get the handler to be used as dependency
    VP_Site_GoogleWebFont::instance()->register();
    wp_register_style('carouselfont', 'path_to_style.css', VP_Site_GoogleWebFont::instance()->get_names());
    wp_enqueue_style('carouselfont');
}
add_action('wp_enqueue_scripts', 'carousel_embed_fonts');

?>