<?php
VP_Security::instance()->whitelist_function('vp_simple_shortcode');

function vp_simple_shortcode($category = "")
{
	$result = '[amazing_carousel category="'.$category.'"]';
	return $result;
}

?>