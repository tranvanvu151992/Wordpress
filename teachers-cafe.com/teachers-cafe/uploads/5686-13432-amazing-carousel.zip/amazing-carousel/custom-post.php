<?php

// Registering Custom Post
add_action( 'init', 'ddd_carousel_custom_post' );
function ddd_carousel_custom_post() {
	register_post_type( 'amazing-carousel',
		array(
			'labels' => array(
				'name' => __( 'Carousels' ),
				'singular_name' => __( 'Carousel' ),
				'add_new_item' => __( 'Add New Carousel' )
			),
			'public' => true,
			'supports' => array('title'),
			'has_archive' => true,
			'rewrite' => array('slug' => 'amazing-carousel'),
			'menu_icon' => 'dashicons-images-alt2',
			'menu_position' => 20,
		)
	);
	
}



// Registering Custom post's category
add_action( 'init', 'ddd_carousel_custom_post_taxonomy'); 
function ddd_carousel_custom_post_taxonomy() {
	register_taxonomy(
		'carousel_cat',  
		'amazing-carousel',
		array(
			'hierarchical'          => true,
			'label'                         => 'Carousel Category',
			'query_var'             => true,
			'show_admin_column'             => true,
			'rewrite'                       => array(
				'slug'                  => 'carousel-cat',
				'with_front'    => true
				)
			)
	);
}



?>