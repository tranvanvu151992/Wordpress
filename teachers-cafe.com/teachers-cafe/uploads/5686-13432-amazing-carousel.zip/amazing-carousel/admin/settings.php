<?php



return array(
	array(
		'type'      => 'group',
		'sortable'  => true,
		'name'      => 'carousel_settings',
		'priority'  => 'high',
		'title'     => __('Carousel Settings', 'vp_textdomain'),
		'fields'    => array(
		
			
			array(
				'type' => 'slider',
				'name' => 'carousel_height',
				'label' => __('Carousel Height <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'description' => __('value in pixel', 'vp_textdomain'),
				'min' => '300',
				'max' => '1000',
				'step' => '1',
				'default' => '600',
			),			
			array(
				'type' => 'color',
				'name' => 'bgcolor',
				'label' => __('Background Color <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'default' => '#eee',
			),
			
			array(
				'type' => 'select',
				'name' => 'style1_fontfamily',
				'label' => __('Custom Font <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'items' => array(
					'data' => array(
						array(
							'source' => 'function',
							'value' => 'vp_get_gwf_family',
						),
					),
				),
			),			
				
			array(
				'type' => 'color',
				'name' => 'title_color',
				'label' => __('Title Color <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
			),
				
			array(
				'type' => 'color',
				'name' => 'desc_color',
				'label' => __('Description Color <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
			),
			
			array(
				'type' => 'radiobutton',
				'name' => 'autoplay',
				'label' => __('AutoPlay <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'items' => array(
					array(
						'value' => 'true',
						'label' => __('Yes', 'vp_textdomain'),
					),
					array(
						'value' => 'false',	
						'label' => __('No', 'vp_textdomain'),
					),
				),

					'default' => array(
						'true',
					),
			),	

			array(
				'type' => 'radiobutton',
				'name' => 'pauseonhover',
				'label' => __('PauseOnHover <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'items' => array(
					array(
						'value' => 'true',
						'label' => __('Yes', 'vp_textdomain'),
					),
					array(
						'value' => 'false',
						'label' => __('No', 'vp_textdomain'),
					),
				),

					'default' => array(
						'true',
					),
			),


			array(
				'type' => 'radiobutton',
				'name' => 'shadow',
				'label' => __('Shadow <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'items' => array(
					array(
						'value' => 'true',
						'label' => __('Yes', 'vp_textdomain'),
					),
					array(
						'value' => 'false',
						'label' => __('No', 'vp_textdomain'),
					),
				),

					'default' => array(
						'true',
					),
			),


			array(
				'type' => 'radiobutton',
				'name' => 'dots',
				'label' => __('Dots <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'items' => array(
					array(
						'value' => 'true',
						'label' => __('Yes', 'vp_textdomain'),
					),
					array(
						'value' => 'false',
						'label' => __('No', 'vp_textdomain'),
					),
				),

					'default' => array(
						'true',
					),
			),




		),
	),


);
/**
 * EOF
 */