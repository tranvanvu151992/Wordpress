<?php



return array(
	array(
		'type'      => 'group',
		'repeating' => true,
		'sortable'  => true,
		'name'      => 'carousel_data',
		'priority'  => 'high',
		'title'     => __('Carousel', 'vp_textdomain'),
		'fields'    => array(
		
	
				
			array(
				'type'  => 'textbox',
				'name'  => 'title_1',
				'label' => __('Name', 'vp_textdomain'),
				'default' => 'Edward Callen',
				
			),	

			array(
				'type'  => 'textbox',
				'name'  => 'title_2',
				'label' => __('Title', 'vp_textdomain'),
				'description' => __('Keep blank if you do not want this', 'vp_textdomain'),
				'default' => 'Web Developer',
				
			),			
			
			array(
				'type'  => 'wpeditor',
				'name'  => 'description',
				'label' => __('Description', 'vp_textdomain'),
				'default' => 'Description goes here',
			),
			

			array(
				'type' => 'upload',
				'name' => 'image_1',
				'label' => __('Image 1', 'vp_textdomain'),
			),
			array(
				'type' => 'upload',
				'name' => 'image_2',
				'label' => __('Image 2', 'vp_textdomain'),
			),
			
			array(
				'type'  => 'textbox',
				'name'  => 'facebook',
				'label' => __('Facebook URL', 'vp_textdomain'),
				
			),
			array(
				'type'  => 'textbox',
				'name'  => 'twitter',
				'label' => __('Twitter URL', 'vp_textdomain'),
				
			),
			array(
				'type'  => 'textbox',
				'name'  => 'google_plus',
				'label' => __('Google-Plus URL', 'vp_textdomain'),
				
			),
			array(
				'type'  => 'textbox',
				'name'  => 'pinterest',
				'label' => __('Pinterest URL', 'vp_textdomain'),
				
			),
			array(
				'type'  => 'textbox',
				'name'  => 'linkedin',
				'label' => __('Linkedin URL', 'vp_textdomain'),
				
			),

			array(
				'type'  => 'textbox',
				'name'  => 'link',
				'label' => __('Custom Link <br /><span style="color: #d63434">Pro Only</span>', 'vp_textdomain'),
				'description' => __('EX. www.google.com Keep blank if you do not want this', 'vp_textdomain'),

			),



		),
	),


);
/**
 * EOF
 */