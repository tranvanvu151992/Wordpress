<?php



return array(
	array(
		'type'      => 'group',
		'name'      => 'shortcode_info',
		'fields'    => array(
				

			array(
				'type'  => 'textbox',
				'name'  => 'category',
				'label' => __('Type Your Category', 'vp_textdomain'),
				'description' => __('must contain category name, this is case sensitive', 'vp_textdomain'),
			),

			
			array(
					'type' => 'textbox',
					'name' => 'shortcode',
					'label' => __('Shortcode', 'vp_textdomain'),
					'description' => __('copy & paste this shortcode post or page ', 'vp_textdomain'),
					'binding' => array(
						'field' => 'category',
						'function' => 'vp_simple_shortcode'
					)
				),

		),
	),
);

/**
 * EOF
 */