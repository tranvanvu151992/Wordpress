=== Amazing Carousel ===
Contributors: wpeffects
Donate link: http://demo.wpeffects.com/
Tags:  carousel, wordpress carousel plugin, wp carousel, amazing carousel, 3d, 3d slider, card slider, css3, css3 animate, image slider, jquery slider, responsive, responsive slider, slider 
Requires at least: 3.0.1
Tested up to: 4.3.1
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Amazing Carousel is a responsive CSS3 3D style carousel wordpress plugin.


== Description ==

Amazing Carousel can make images into 3d style and animate them use CSS 3D transforms and CSS animations. 

See live demo here: http://demo.wpeffects.com/amazing-carousel



<strong>Features</strong>
<ul>
	<li>Super easy installation.</li>
	<li>Responsive.</li>
	<li>3D style with CSS3.</li>
	<li>Custom ordering.</li>
	<li>Unlimited carousels via custom post. </li>
	<li>Modern and beautiful design.</li>
	<li>Category Support. </li>
	<li>Shortcode generator. </li>
	<li>Very lightweight. </li>
	<li>Work on all modern browsers that support CSS3 3D Transforms.</li>

</ul>


<strong><a href="http://demo.wpeffects.com/amazing-carousel">Pro Version Features</a></strong>
<ul>
	<li>Unlimited color for title and description.</li>
	<li>Custom carousel height.</li>
	<li>Custom background color.</li>
	<li>650+ goole font.</li>
	<li>AutoPlay control.</li>
	<li>Pagination & Navigation controls.</li>
	<li>Custom link option.</li>
	<li>Support within 12 hours.</li>
</ul>



== Installation ==

Installing this plugin as regular wordpress plugin.

After install, this plugin enable a custom post called <strong>Carousels</strong>. Add category & add carousel data. To add more item click on <strong>Add More Carousel</strong>. 
After adding items, first you need enter your category on shortcode generator at top right. Use category title, not category id or slug. Make sure spelling is ok. It is case sensitive. You can customize the plugin with plugin settings under the post, after customizing click insert and save the post. copy shortcode from sidebar and you are ready to use this plugin in your post, page. 

Go to page > Add New. On the editor, just paste the shortcode.



== Screenshots ==

1. Custom post
2. Plugin settings
3. Plugin shortcode
4. Plugin shortcode copy
5. Cutom post category


== Changelog ==

= 1.5 =
* Fixed layout issue

= 1.4 =
* Improved settings panel 

= 1.3.1 =
* Pro version available now

= 1.3.0 =
* Fixed blank page display

= 1.0 =
* First Release


== Upgrade Notice ==

= 1.5 =
* Fixed layout issue

= 1.4 =
* Improved settings panel

= 1.3.1 =
* Pro version available now

= 1.3.0 =
* Fixed blank page display

= 1.0 =
* First Release