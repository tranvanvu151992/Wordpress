<?php

function ddd_carousel_shortcode($atts){
	extract( shortcode_atts( array(
		'category' => '',
	), $atts) );
	
    $query = new WP_Query(
        array('posts_per_page' => '-1', 'post_type' => 'amazing-carousel', 'carousel_cat' => $category)
        );		
		
$autoplay = vp_metabox('carousel_settings_metabox.carousel_settings.0.autoplay', false);
$pauseonhover = vp_metabox('carousel_settings_metabox.carousel_settings.0.pauseonhover', false);
$shadow = vp_metabox('carousel_settings_metabox.carousel_settings.0.shadow', false);
$dots = vp_metabox('carousel_settings_metabox.carousel_settings.0.dots', false);	
	
	
	$output = '
				<script>
			jQuery(function ($) {
				$("#amazing_carousel").cardSlider({
					
					autoPlay: true,
					pauseOnHover: false,
					shadow: true,
					dots: true,
					
					
				});
				
			});
		</script>

	';
		

	while($query->have_posts()) : $query->the_post();
	$ids = get_the_ID();
		
	// Calling metabox data
	$infos = vp_metabox('carousel_metabox.carousel_data', false);

		
$i = 0;

	$output .='<div id="amazing_carousel" class="cardslider lightskin ">';

	foreach ($infos as $info) {	

		$output .='

        <div class="cs-slide">
            <div class="cs-description">
                <h2 class="cs-desc-title">'.$info[title_1].'<span>'.$info[title_2].'</span></h2>


                <div class="cs-desc-content">
                    <p>'.$info[description].'</p>

                    <div class="social-links">

                    ';

                if ($info[facebook]) {

                $output .='<a href="'.$info[facebook].'" class="facebook">
                            <i class="fa fa-facebook"></i>
                        </a>';
                }
                


                 if ($info[twitter]) {

                $output .='<a href="'.$info[twitter].'" class="twitter">
                            <i class="fa fa-twitter"></i>
                        </a>';
                } 
                  
                if ($info[google_plus]) {

                $output .='<a href="'.$info[google_plus].'" class="google-plus">
                            <i class="fa fa-google-plus"></i>
                        </a>';
                }
                  
                if ($info[pinterest]) {

                $output .='<a href="'.$info[pinterest].'" class="pinterest">
                            <i class="fa fa-pinterest-p"></i>
                        </a>';
                }
                  
                if ($info[linkedin]) {

                $output .='<a href="'.$info[linkedin].'" class="linkedin">
                            <i class="fa fa-linkedin"></i>
                        </a>';
                }
                       
                        
         $output .='</div>
                </div>
            </div>

            <div class="cs-media">';
			
			if ($info[image_1]) {
				
				$output .='<a href="#" class="cs-media-item"><img src="'.$info[image_1].'" alt=""/></a>';
			}
			
			if ($info[image_2]) {
				
				$output .='<a href="#" class="cs-media-item"><img src="'.$info[image_2].'" alt=""/></a>';
			}			
                
                
                
        $output .='</div>

        </div>	';    	
		

		
		$i++;
	}	
    endwhile;
	
	$output .='<style>
				.lightskin {
						background: #eee;
					}
				.cardslider {
					  height: 600px;
					}
			</style>';
			
	$output .='</div>';
	
	wp_reset_query();
	return $output;
}
add_shortcode('amazing_carousel', 'ddd_carousel_shortcode');	

?>