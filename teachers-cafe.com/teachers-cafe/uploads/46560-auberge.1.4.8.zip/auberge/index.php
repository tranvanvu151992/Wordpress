<?php
/**
 * General index template
 *
 * @package    Auberge
 * @copyright  2015 WebMan - Oliver Juhas
 * @version    1.0
 */



get_header();

	get_template_part( 'loop', 'index' );

get_footer();

?>